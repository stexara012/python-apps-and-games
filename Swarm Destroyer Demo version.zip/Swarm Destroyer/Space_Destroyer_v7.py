import pygame
import random
import os
import math
import json
import time

pygame.init()

# === WINDOW ===
WIDTH, HEIGHT = 1440, 810
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bridge Battle — Swarm Surge v7")
clock = pygame.time.Clock()

background = pygame.image.load("background.png").convert()
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

SCALE = 1.5
SPRITE = int(64 * SCALE)
GROUND_Y = HEIGHT - int(220 * (HEIGHT / 600))
HALF_X = WIDTH // 2

# === FRAMES ===
def load_frames_from_folder(path):
    files = sorted(os.listdir(path), key=lambda x: int(x.split("_")[-1].split(".")[0]))
    out = []
    for f in files:
        if f.endswith(".png"):
            img = pygame.image.load(os.path.join(path, f)).convert_alpha()
            out.append(pygame.transform.scale(img, (SPRITE, SPRITE)))
    return out

player_frames = load_frames_from_folder("output/player_frames")
player_idle  = player_frames[0:5]
player_walk  = player_frames[5:10]
player_shoot = player_frames[10:15]

enemy_frames = load_frames_from_folder("output/enemy_frames")
soldier_fixed = [pygame.transform.flip(f, True, False) for f in enemy_frames[8:12]]
enemy_types = {
    "hover":   enemy_frames[0:4],
    "walker":  enemy_frames[4:8],
    "soldier": soldier_fixed,
    "flyer":   enemy_frames[12:15],
}
# Boss
BOSS_SCALE = 2.5
BOSS_SIZE = int(SPRITE * BOSS_SCALE)
boss_frame_sets = {
    name: [pygame.transform.scale(f, (BOSS_SIZE, BOSS_SIZE)) for f in frames]
    for name, frames in enemy_types.items()
}

# === Tint helper za varijante (elite, kamikaza, tank...) ===
def tint_frames(frames, color, alpha=110):
    out = []
    for f in frames:
        c = f.copy()
        overlay = pygame.Surface(c.get_size(), pygame.SRCALPHA)
        overlay.fill((*color, alpha))
        c.blit(overlay, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        out.append(c)
    return out

# Predračunate tintovane verzije
TINTS = {
    "elite":    (255, 215, 80),    # zlato
    "tank":     (140, 200, 255),   # plavo
    "kamikaza": (255, 90, 90),     # crveno
    "sniper":   (200, 120, 255),   # ljubičasto
    "zerg":     (180, 255, 140),   # zeleno
}
tinted_sets = {
    variant: {name: tint_frames(frames, col)
              for name, frames in enemy_types.items()}
    for variant, col in TINTS.items()
}

# === SOUND ===
try:
    pygame.mixer.init(frequency=22050, size=-16, channels=1)
    import array
    def make_beep(freq, ms, vol=0.25, decay=True):
        sr = 22050
        n = int(sr * ms / 1000)
        buf = array.array("h")
        amp = int(32767 * vol)
        for i in range(n):
            t = i / sr
            env = (1 - i/n) if decay else 1
            v = int(math.sin(2*math.pi*freq*t) * amp * env)
            buf.append(v)
        return pygame.mixer.Sound(buffer=buf.tobytes())
    snd_shoot = make_beep(880, 60, 0.18)
    snd_hit   = make_beep(220, 80, 0.28)
    snd_pick  = make_beep(1200, 120, 0.25)
    snd_dmg   = make_beep(120, 150, 0.35)
    snd_jump  = make_beep(520, 80, 0.18)
    snd_boom  = make_beep(80, 250, 0.4)
    snd_ach   = make_beep(1500, 200, 0.22)
    SOUND = True
except Exception:
    SOUND = False

def play(s):
    if SOUND:
        try: s.play()
        except: pass

# === HIGH SCORE ===
HS_FILE = "highscore.json"
def load_hs():
    try:
        with open(HS_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {"high_score": 0, "best_wave": 0, "total_kills": 0}
def save_hs(data):
    try:
        with open(HS_FILE, "w") as f:
            json.dump(data, f)
    except Exception:
        pass
hs_data = load_hs()

# === PLAYER ===
player = pygame.Rect(150, GROUND_Y, SPRITE, SPRITE)
player_speed = 6
player_anim = player_idle
frame_index = 0
anim_speed = 0.15
state = "idle"
facing_right = True

player_max_hp = 100
player_hp = 100

shield_max = 100
shield_energy = 100
shield_active = False
shield_locked = False
shield_regen = 0.18
shield_drain = 0.55
SHIELD_PAD = 70

vel_y = 0
on_ground = True
GRAVITY = 0.9
JUMP_V = -16

shoot_cooldown = 0
SHOOT_DELAY = 18

dash_cd = 0
DASH_CD_MAX = 90
dash_time = 0
DASH_DUR = 10
dash_dir = 1

rapid_timer = 0
triple_timer = 0
mult_timer = 0

combo = 0
combo_timer = 0
COMBO_WINDOW = 90
max_combo_run = 0

shake = 0

bullets = []
enemy_bullets = []
rockets = []
particles = []
powerups = []
laser_warns = []   # {x,y,timer,dmg_timer}
toasts = []        # {text, life, color}

# Stats
stats = {"shots_fired": 0, "shots_hit": 0, "kills": 0, "start_ts": time.time()}
achievements_done = set()

rocket_cd = 0
ROCKET_CD_MAX = 150
ROCKET_DMG = 18
ROCKET_AOE_DMG = 10
ROCKET_AOE_RADIUS = 110

POW_TYPES = ["heal", "rapid", "triple", "shield", "mult"]
POW_COLORS = {"heal":(80,255,120), "rapid":(255,220,80),
              "triple":(255,140,80), "shield":(80,180,255), "mult":(220,120,255)}
PICKUP_COLORS = {"hp_pack": (80,255,120), "shield_pack": (80,180,255)}

def spawn_particles(x, y, color, n=14, speed=4, life=28):
    for _ in range(n):
        a = random.random()*math.tau
        sp = random.uniform(speed*0.3, speed)
        particles.append({"x":x,"y":y,"vx":math.cos(a)*sp,"vy":math.sin(a)*sp,
                          "life":life,"max":life,"col":color,"size":random.randint(2,4)})

def push_toast(text, color=(255,220,80)):
    toasts.append({"text": text, "life": 180, "color": color})
    play(snd_ach)

def unlock(key, label):
    if key in achievements_done: return
    achievements_done.add(key)
    push_toast(f"★ {label}", (255, 220, 100))

# === ENEMY VARIANTS ===
# variant: regular | zerg | tank | kamikaza | sniper
# elite je modifikator nad bilo kojim (osim boss)
def pick_variant(wave_num):
    # Sa wave-om sve više specijalaca
    roll = random.random()
    if wave_num >= 5 and roll < 0.12: return "sniper"
    if wave_num >= 4 and roll < 0.24: return "kamikaza"
    if wave_num >= 3 and roll < 0.38: return "tank"
    if wave_num >= 2 and roll < 0.55: return "zerg"
    return "regular"

class Enemy:
    def __init__(self, boss=False, wave_num=1, formation_y=None, formation_phase=0.0):
        self.boss = boss
        self.elite = False
        self.variant = "regular"
        self.formation_phase = formation_phase
        self.spawn_time = pygame.time.get_ticks()

        if boss:
            self.type = random.choice(list(boss_frame_sets.keys()))
            self.anim = boss_frame_sets[self.type]
            y = GROUND_Y - (BOSS_SIZE - SPRITE) if self.type != "flyer" else GROUND_Y - 160
            self.rect = pygame.Rect(WIDTH, y, BOSS_SIZE, BOSS_SIZE)
            self.maxhp = 30 + wave_num * 5
            self.hp = self.maxhp
            self.speed = 1
            self.max_shield = 40 + wave_num * 3
            self.shield = self.max_shield
        else:
            self.type = random.choice(list(enemy_types.keys()))
            self.variant = pick_variant(wave_num)
            # Bira frame set: tinted ako je varijanta, regular inače
            if self.variant != "regular":
                self.anim = tinted_sets[self.variant][self.type]
            else:
                self.anim = enemy_types[self.type]

            y = GROUND_Y if self.type != "flyer" else GROUND_Y - 120
            if formation_y is not None:
                y = formation_y
            self.rect = pygame.Rect(WIDTH, y, SPRITE, SPRITE)

            speeds = {"hover":3, "walker":2, "soldier":2, "flyer":4}
            base_speed = speeds[self.type]

            # HP / speed / shield po varijanti
            self.maxhp = 3 + wave_num // 2
            self.max_shield = 0
            if self.variant == "zerg":
                self.maxhp = max(1, self.maxhp - 1)
                base_speed += 2
            elif self.variant == "tank":
                self.maxhp += 4
                base_speed = max(1, base_speed - 1)
                self.max_shield = 4 + wave_num // 2
            elif self.variant == "kamikaza":
                self.maxhp = max(1, self.maxhp - 1)
                base_speed += 1
            elif self.variant == "sniper":
                base_speed = max(1, base_speed - 1)
            else:
                # regular sa povremenim shieldom
                if wave_num >= 3 and random.random() < min(0.10 + wave_num*0.03, 0.4):
                    self.max_shield = 2 + wave_num // 2

            # Elite modifier
            if random.random() < min(0.05 + wave_num * 0.01, 0.15):
                self.elite = True
                self.maxhp = int(self.maxhp * 2)
                self.max_shield = int(self.max_shield * 1.5)

            self.speed = base_speed
            self.hp = self.maxhp
            self.shield = self.max_shield

        self.frame = 0
        # snipers šaljnu retke ali brze pucnje; kamikaza ne puca
        if not boss and self.variant == "sniper":
            self.shoot_timer = random.randint(80, 140)
        elif not boss and self.variant == "kamikaza":
            self.shoot_timer = 99999
        else:
            self.shoot_timer = random.randint(60, 180)
        self._base_y = self.rect.y

    def update(self):
        target_x = HALF_X - (self.rect.width if self.boss else 0)
        if self.rect.x > target_x:
            self.rect.x -= self.speed

        # Sinusno talasanje za neprijatelje koji su spawned u talasnoj formaciji
        if self.formation_phase != 0.0 and not self.boss:
            t = (pygame.time.get_ticks() - self.spawn_time) / 300.0
            self.rect.y = self._base_y + int(math.sin(t + self.formation_phase) * 35)

        self.frame = (self.frame + 0.1) % len(self.anim)
        self.shoot_timer -= 1

        if self.boss:
            if self.shoot_timer <= 0 and self.rect.x <= HALF_X + 250:
                for ang in (-0.3, -0.15, 0, 0.15, 0.3):
                    eb = pygame.Rect(self.rect.centerx, self.rect.centery, 14, 6)
                    enemy_bullets.append({"rect": eb, "dx": -8, "dy": ang*8})
                self.shoot_timer = random.randint(50, 90)
            return

        if self.variant == "sniper":
            # Telegraph laser, pa damage
            if self.shoot_timer <= 0 and self.rect.x <= WIDTH - 100:
                laser_warns.append({"y": self.rect.centery, "x_from": self.rect.x,
                                    "warn": 35, "fire": 8})
                self.shoot_timer = random.randint(160, 260)
        elif self.variant != "kamikaza":
            if self.shoot_timer <= 0 and self.rect.x <= HALF_X + 250:
                eb = pygame.Rect(self.rect.centerx, self.rect.centery, 12, 5)
                enemy_bullets.append({"rect": eb, "dx": -8, "dy": 0})
                self.shoot_timer = random.randint(90, 200)

    def draw(self):
        img = self.anim[int(self.frame)]
        screen.blit(img, img.get_rect(center=(self.rect.centerx+sx, self.rect.centery+sy)))
        # Elite glow
        if self.elite:
            r = self.rect
            s = pygame.Surface((r.width+20, r.height+20), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (255, 215, 80, 60), s.get_rect())
            screen.blit(s, (r.x+sx-10, r.y+sy-10))

enemies = []
wave = 1
spawn_timer = 0
enemies_to_spawn = 5
boss_spawned = False
score = 0
game_over = False
paused = False
wave_no_hit = True   # za achievement
formation_mode = None  # None | "v" | "wave"
formation_queue = []   # lista (y, phase) za naredne spawn-ove

font = pygame.font.SysFont(None, 36)
big_font = pygame.font.SysFont(None, 96)
small_font = pygame.font.SysFont(None, 24)
mid_font = pygame.font.SysFont(None, 48)

def draw_text(t, x, y, c=(255,255,255), f=font):
    screen.blit(f.render(t, True, c), (x, y))

def draw_text_centered(t, cx, y, c=(255,255,255), f=font):
    surf = f.render(t, True, c)
    screen.blit(surf, surf.get_rect(center=(cx, y)))

def draw_bar(x, y, w, h, value, maxv, color, bg=(40,40,40)):
    pygame.draw.rect(screen, bg, (x, y, w, h))
    fw = int(w * max(0, value) / max(1, maxv))
    pygame.draw.rect(screen, color, (x, y, fw, h))
    pygame.draw.rect(screen, (200,200,200), (x, y, w, h), 2)

def reset_game():
    global player_hp, shield_energy, shield_locked, wave, enemies_to_spawn, score
    global game_over, vel_y, on_ground, boss_spawned, combo, combo_timer
    global rapid_timer, triple_timer, mult_timer, dash_cd, rocket_cd
    global player_max_hp, shield_max, paused, wave_no_hit, formation_mode, formation_queue
    global max_combo_run, stats, achievements_done
    player.x, player.y = 150, GROUND_Y
    player_max_hp = 100
    shield_max = 100
    player_hp = player_max_hp
    shield_energy = shield_max
    shield_locked = False
    bullets.clear(); enemy_bullets.clear(); enemies.clear()
    rockets.clear(); laser_warns.clear(); toasts.clear()
    particles.clear(); powerups.clear()
    wave = 1; enemies_to_spawn = 5; score = 0
    game_over = False; vel_y = 0; on_ground = True
    boss_spawned = False
    combo = 0; combo_timer = 0
    max_combo_run = 0
    rapid_timer = triple_timer = mult_timer = 0
    dash_cd = 0
    rocket_cd = 0
    paused = False
    wave_no_hit = True
    formation_mode = None
    formation_queue = []
    stats = {"shots_fired": 0, "shots_hit": 0, "kills": 0, "start_ts": time.time()}
    achievements_done = set()

def setup_formation_for_wave(w):
    """Možda postavi formaciju za sledeći wave."""
    global formation_mode, formation_queue
    formation_mode = None
    formation_queue = []
    if w < 2: return
    roll = random.random()
    if roll < 0.30:
        # V-formacija: 5 neprijatelja u V-u, ulaze grupisano
        formation_mode = "v"
        center_y = GROUND_Y - 80
        formation_queue = [(center_y, 0)]
        for k in (1, 2):
            formation_queue.append((center_y - k*55, 0))
            formation_queue.append((center_y + k*55, 0))
    elif roll < 0.55:
        # Sinusoidalni talas — svi imaju različit fazni offset
        formation_mode = "wave"
        for i in range(6):
            formation_queue.append((GROUND_Y - 60, i * 0.6))

def kill_enemy(e):
    global combo, combo_timer, score, shake, max_combo_run
    spawn_particles(e.rect.centerx, e.rect.centery, (255,120,80), n=24, speed=6, life=30)
    stats["kills"] += 1
    if stats["kills"] >= 100:
        unlock("kills_100", "100 KILLS")

    if e.boss:
        shake = 18
        score += 200 * (2 if mult_timer>0 else 1)
        for i, pt in enumerate(("hp_pack", "shield_pack")):
            powerups.append({"rect": pygame.Rect(e.rect.centerx-12 + i*40, GROUND_Y+20, 24, 24), "type": pt})
        t = random.choice(POW_TYPES)
        powerups.append({"rect": pygame.Rect(e.rect.centerx-12 - 40, GROUND_Y+20, 24, 24), "type": t})
        unlock("first_boss", "FIRST BOSS DOWN")
    else:
        combo += 1; combo_timer = COMBO_WINDOW
        if combo > max_combo_run: max_combo_run = combo
        if combo >= 10:
            unlock("combo_10", "10x COMBO")
        base = 10 + combo*2
        mul = 1
        if e.elite: mul *= 2
        if mult_timer>0: mul *= 2
        score += base * mul
        # Drop logika
        rr = random.random()
        if e.elite:
            # Elite uvek dropuje nešto dobro
            pool = ["hp_pack", "shield_pack"] + POW_TYPES
            t = random.choice(pool)
            powerups.append({"rect": pygame.Rect(e.rect.centerx-12, GROUND_Y+20, 24, 24), "type": t})
        else:
            if rr < 0.18:
                powerups.append({"rect": pygame.Rect(e.rect.centerx-12, GROUND_Y+20, 24, 24), "type": "hp_pack"})
            elif rr < 0.32:
                powerups.append({"rect": pygame.Rect(e.rect.centerx-12, GROUND_Y+20, 24, 24), "type": "shield_pack"})
            elif rr < 0.50:
                t = random.choice(POW_TYPES)
                powerups.append({"rect": pygame.Rect(e.rect.centerx-12, GROUND_Y+20, 24, 24), "type": t})
    if e in enemies: enemies.remove(e)

def kamikaza_explode(e):
    """Kamikaza eksplodira pri kontaktu/smrti — splash damage igrača."""
    global player_hp, shake, wave_no_hit
    cx, cy = e.rect.centerx, e.rect.centery
    spawn_particles(cx, cy, (255, 200, 60), n=40, speed=7, life=28)
    spawn_particles(cx, cy, (255, 80, 40), n=20, speed=4, life=22)
    shake = max(shake, 12)
    play(snd_boom)
    # damage igraču ako je u radijusu
    R = 130
    dx = player.centerx - cx
    dy = player.centery - cy
    if dx*dx + dy*dy <= R*R:
        if shield_active:
            pass  # shield apsorbuje
        else:
            player_hp -= 18
            wave_no_hit = False

running = True
setup_formation_for_wave(wave)

while running:
    clock.tick(60)

    sx = random.randint(-shake, shake) if shake else 0
    sy = random.randint(-shake, shake) if shake else 0
    if shake > 0: shake -= 1

    screen.blit(background, (sx, sy))

    keys = pygame.key.get_pressed()
    moving = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE and not game_over:
                paused = not paused
            if game_over and event.key == pygame.K_r:
                reset_game()
                setup_formation_for_wave(wave)
            if not game_over and not paused:
                if event.key == pygame.K_SPACE and shoot_cooldown <= 0:
                    delay = SHOOT_DELAY // 2 if rapid_timer > 0 else SHOOT_DELAY
                    dx = 14 if facing_right else -14
                    bx = player.centerx + (24 if facing_right else -24)
                    if triple_timer > 0:
                        for off in (-10, 0, 10):
                            bullets.append({"rect": pygame.Rect(bx, player.centery+off, 12, 5), "dx": dx, "dy": off*0.05})
                            stats["shots_fired"] += 1
                    else:
                        bullets.append({"rect": pygame.Rect(bx, player.centery, 12, 5), "dx": dx, "dy": 0})
                        stats["shots_fired"] += 1
                    spawn_particles(bx, player.centery, (255,230,120), n=6, speed=3, life=10)
                    state = "shoot"; shoot_cooldown = delay
                    play(snd_shoot)
                if event.key == pygame.K_w and on_ground:
                    vel_y = JUMP_V; on_ground = False
                    play(snd_jump)
                    spawn_particles(player.centerx, player.bottom, (200,200,200), n=8, speed=2, life=14)
                if event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT) and dash_cd <= 0:
                    dash_time = DASH_DUR
                    dash_dir = 1 if facing_right else -1
                    dash_cd = DASH_CD_MAX
                if event.key == pygame.K_f and rocket_cd <= 0:
                    dx = 12 if facing_right else -12
                    bx = player.centerx + (24 if facing_right else -24)
                    rockets.append({"rect": pygame.Rect(bx, player.centery, 18, 10),
                                    "dx": dx, "dy": 0})
                    rocket_cd = ROCKET_CD_MAX
                    state = "shoot"
                    play(snd_shoot)
                    spawn_particles(bx, player.centery, (255,160,60), n=10, speed=4, life=14)
            # Pause meni hotkeys
            if paused and not game_over:
                if event.key == pygame.K_r:
                    reset_game(); setup_formation_for_wave(wave)
                if event.key == pygame.K_q:
                    running = False

    if not game_over and not paused:
        if keys[pygame.K_a]:
            player.x -= player_speed; moving = True; facing_right = False
        if keys[pygame.K_d]:
            player.x += player_speed; moving = True; facing_right = True

        if dash_time > 0:
            player.x += dash_dir * 18
            spawn_particles(player.centerx, player.centery, (180,220,255), n=2, speed=1, life=12)
            dash_time -= 1
        if dash_cd > 0: dash_cd -= 1

        player.x = max(0, min(WIDTH - player.width, player.x))

        vel_y += GRAVITY
        player.y += int(vel_y)
        if player.y >= GROUND_Y:
            player.y = GROUND_Y; vel_y = 0; on_ground = True

        # Shield (Q sada koristim samo van pause-a; konflikt sa quit u pause meniju nije problem)
        wants = keys[pygame.K_q]
        if shield_locked:
            shield_active = False
            shield_energy = min(shield_max, shield_energy + shield_regen)
            if shield_energy >= shield_max:
                shield_locked = False
        else:
            shield_active = wants and shield_energy > 0
            if shield_active:
                shield_energy -= shield_drain
                if shield_energy <= 0:
                    shield_energy = 0; shield_active = False; shield_locked = True
            else:
                shield_energy = min(shield_max, shield_energy + shield_regen)

        if shoot_cooldown > 0: shoot_cooldown -= 1
        if rocket_cd > 0: rocket_cd -= 1
        if rapid_timer > 0: rapid_timer -= 1
        if triple_timer > 0: triple_timer -= 1
        if mult_timer > 0: mult_timer -= 1
        if combo_timer > 0:
            combo_timer -= 1
            if combo_timer == 0: combo = 0

        if state == "shoot":   player_anim = player_shoot
        elif moving:           player_anim = player_walk
        else:                  player_anim = player_idle
        frame_index = (frame_index + anim_speed) % len(player_anim)
        if state == "shoot" and frame_index < anim_speed: state = "idle"

        for b in bullets:
            b["rect"].x += b["dx"]
            b["rect"].y += int(b.get("dy", 0))
        bullets = [b for b in bullets if 0 < b["rect"].x < WIDTH]
        for b in enemy_bullets:
            b["rect"].x += b["dx"]
            b["rect"].y += int(b.get("dy", 0))
        enemy_bullets = [b for b in enemy_bullets if 0 < b["rect"].x < WIDTH]

        for r in rockets:
            r["rect"].x += r["dx"]
            spawn_particles(r["rect"].centerx, r["rect"].centery,
                            (180,180,180), n=2, speed=1, life=14)
        rockets = [r for r in rockets if 0 < r["rect"].x < WIDTH]

        # === SPAWN ===
        spawn_timer += 1
        spawn_delay = max(18, 60 - wave * 3)
        if spawn_timer > spawn_delay and enemies_to_spawn > 0:
            # Formacija ima prioritet ako ima u redu
            if formation_queue:
                fy, phase = formation_queue.pop(0)
                e = Enemy(wave_num=wave, formation_y=fy, formation_phase=phase)
                enemies.append(e)
                enemies_to_spawn -= 1
                spawn_timer = 0
            else:
                enemies.append(Enemy(wave_num=wave))
                spawn_timer = 0
                enemies_to_spawn -= 1
                if wave >= 2 and enemies_to_spawn > 0 and random.random() < 0.25:
                    burst = min(random.randint(1, 2 + wave // 3), enemies_to_spawn)
                    for _ in range(burst):
                        e = Enemy(wave_num=wave)
                        e.rect.x += random.randint(40, 200)
                        enemies.append(e)
                        enemies_to_spawn -= 1

        # Boss
        if wave % 3 == 0 and not boss_spawned and enemies_to_spawn == 0 and len([e for e in enemies if not e.boss]) == 0:
            enemies.append(Enemy(boss=True, wave_num=wave))
            boss_spawned = True

        for e in enemies: e.update()

        # === LASER WARNINGS (sniper) ===
        for lw in laser_warns[:]:
            if lw["warn"] > 0:
                lw["warn"] -= 1
                if lw["warn"] == 0:
                    # Pucanje: damage ako je igrač u liniji
                    pr = pygame.Rect(0, lw["y"]-3, lw["x_from"], 6)
                    if pr.colliderect(player) and not shield_active:
                        player_hp -= 14
                        wave_no_hit = False
                        spawn_particles(player.centerx, player.centery, (200,120,255), n=12, speed=4, life=18)
                        play(snd_dmg)
                        shake = max(shake, 8)
                    lw["fire"] = 8
            else:
                lw["fire"] -= 1
                if lw["fire"] <= 0:
                    laser_warns.remove(lw)

        # Bullets vs enemies
        for b in bullets[:]:
            for e in enemies[:]:
                if b["rect"].colliderect(e.rect):
                    stats["shots_hit"] += 1
                    if e.shield > 0:
                        e.shield -= 1
                        spawn_particles(b["rect"].x, b["rect"].y, (140,220,255), n=8, speed=3, life=12)
                    else:
                        e.hp -= 1
                        spawn_particles(b["rect"].x, b["rect"].y, (255,200,80), n=8, speed=3, life=14)
                    if b in bullets: bullets.remove(b)
                    play(snd_hit)
                    if e.hp <= 0:
                        kill_enemy(e)
                    break

        # Rockets vs enemies
        for r in rockets[:]:
            hit_e = None
            for e in enemies:
                if r["rect"].colliderect(e.rect):
                    hit_e = e; break
            if hit_e is not None:
                stats["shots_hit"] += 1
                cx, cy = r["rect"].centerx, r["rect"].centery
                spawn_particles(cx, cy, (255,180,60), n=40, speed=7, life=28)
                spawn_particles(cx, cy, (255,80,40), n=20, speed=4, life=22)
                shake = max(shake, 10)
                play(snd_boom)
                if hit_e.shield > 0:
                    absorb = min(hit_e.shield, ROCKET_DMG)
                    hit_e.shield -= absorb
                    rem = ROCKET_DMG - absorb
                    if rem > 0: hit_e.hp -= rem
                else:
                    hit_e.hp -= ROCKET_DMG
                for e in enemies[:]:
                    if e is hit_e: continue
                    dx = e.rect.centerx - cx
                    dy = e.rect.centery - cy
                    if dx*dx + dy*dy <= ROCKET_AOE_RADIUS*ROCKET_AOE_RADIUS:
                        if e.shield > 0:
                            absorb = min(e.shield, ROCKET_AOE_DMG)
                            e.shield -= absorb
                            rem = ROCKET_AOE_DMG - absorb
                            if rem > 0: e.hp -= rem
                        else:
                            e.hp -= ROCKET_AOE_DMG
                for e in enemies[:]:
                    if e.hp <= 0:
                        kill_enemy(e)
                if r in rockets: rockets.remove(r)

        # Enemy bullets vs player
        shield_rect = player.inflate(SHIELD_PAD, SHIELD_PAD)
        for b in enemy_bullets[:]:
            if shield_active and b["rect"].colliderect(shield_rect):
                enemy_bullets.remove(b)
                spawn_particles(b["rect"].x, b["rect"].y, (140,220,255), n=8, speed=3, life=14)
                continue
            if b["rect"].colliderect(player):
                enemy_bullets.remove(b); player_hp -= 8
                wave_no_hit = False
                spawn_particles(player.centerx, player.centery, (255,80,80), n=10, speed=4, life=18)
                shake = max(shake, 6); play(snd_dmg)

        # Kontakt
        for e in enemies[:]:
            if e.rect.colliderect(player):
                if not e.boss and e.variant == "kamikaza":
                    kamikaza_explode(e)
                    if e in enemies: enemies.remove(e)
                    stats["kills"] += 1
                    continue
                if not shield_active:
                    player_hp -= 0.5
                    wave_no_hit = False
                else:
                    e.rect.x -= 4

        # Powerups pickup
        for p in powerups[:]:
            if p["rect"].colliderect(player):
                t = p["type"]
                if t == "heal":     player_hp = min(player_max_hp, player_hp + 30)
                elif t == "rapid":  rapid_timer = 60*6
                elif t == "triple": triple_timer = 60*6
                elif t == "shield":
                    shield_energy = shield_max; shield_locked = False
                elif t == "mult":   mult_timer = 60*8
                elif t == "hp_pack":
                    player_hp = min(player_max_hp, player_hp + 25)
                elif t == "shield_pack":
                    shield_energy = min(shield_max, shield_energy + 35)
                    if shield_energy >= shield_max * 0.5: shield_locked = False
                col = POW_COLORS.get(t, PICKUP_COLORS.get(t, (255,255,255)))
                spawn_particles(p["rect"].centerx, p["rect"].centery, col, n=16, speed=4, life=22)
                play(snd_pick)
                powerups.remove(p)

        if player_hp <= 0:
            player_hp = 0; game_over = True; shake = 16
            # Save high score
            if score > hs_data.get("high_score", 0):
                hs_data["high_score"] = score
            if wave > hs_data.get("best_wave", 0):
                hs_data["best_wave"] = wave
            hs_data["total_kills"] = hs_data.get("total_kills", 0) + stats["kills"]
            save_hs(hs_data)

        if len(enemies) == 0 and enemies_to_spawn == 0 and (wave % 3 != 0 or boss_spawned):
            if wave_no_hit and wave > 1:
                unlock(f"nohit_w{wave}", f"NO-HIT WAVE {wave}")
            wave += 1
            enemies_to_spawn = 5 + wave * 2
            boss_spawned = False
            player_max_hp += 10
            shield_max += 8
            player_hp = min(player_max_hp, player_hp + 15)
            shield_energy = min(shield_max, shield_energy + 20)
            wave_no_hit = True
            setup_formation_for_wave(wave)
            push_toast(f"WAVE {wave}", (180, 220, 255))

    # === DRAW ===
    # Particles
    for p in particles[:]:
        p["x"] += p["vx"]; p["y"] += p["vy"]
        p["vy"] += 0.15
        p["life"] -= 1
        if p["life"] <= 0: particles.remove(p); continue
        a = max(0, min(255, int(255 * p["life"]/p["max"])))
        s = pygame.Surface((p["size"]*2, p["size"]*2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*p["col"], a), (p["size"], p["size"]), p["size"])
        screen.blit(s, (p["x"]+sx-p["size"], p["y"]+sy-p["size"]))

    # Powerups
    t_now = pygame.time.get_ticks() / 200
    for p in powerups:
        c = POW_COLORS.get(p["type"], PICKUP_COLORS.get(p["type"], (255,255,255)))
        r = p["rect"].copy(); r.x += sx; r.y += sy
        pulse = 4 + int(3*math.sin(t_now))
        s = pygame.Surface((r.width+pulse*2, r.height+pulse*2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*c, 80), (s.get_width()//2, s.get_height()//2), s.get_width()//2)
        screen.blit(s, (r.x-pulse, r.y-pulse))
        pygame.draw.rect(screen, c, r)
        letters = {"heal":"+", "rapid":"R", "triple":"3", "shield":"S", "mult":"x2",
                   "hp_pack":"♥", "shield_pack":"◊"}
        letter = letters.get(p["type"], "?")
        draw_text(letter, r.x+4, r.y+2, (10,10,10), small_font)

    # Player
    img = player_anim[int(frame_index)]
    if not facing_right: img = pygame.transform.flip(img, True, False)
    screen.blit(img, img.get_rect(center=(player.centerx+sx, player.centery+sy)))

    if shield_active and not shield_locked:
        sr = player.inflate(SHIELD_PAD, SHIELD_PAD)
        s = pygame.Surface((sr.width, sr.height), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (60, 180, 255, 70), s.get_rect())
        pygame.draw.ellipse(s, (140, 230, 255, 220), s.get_rect(), 4)
        screen.blit(s, (sr.x+sx, sr.y+sy))

    for b in bullets:
        pygame.draw.rect(screen, (255, 255, 120), b["rect"].move(sx,sy))
    for b in enemy_bullets:
        pygame.draw.rect(screen, (255, 80, 80), b["rect"].move(sx,sy))

    for r in rockets:
        rr = r["rect"].move(sx, sy)
        pygame.draw.rect(screen, (60, 60, 60), rr)
        pygame.draw.rect(screen, (255, 140, 40), rr.inflate(-2,-2))
        pygame.draw.rect(screen, (255, 230, 120),
                         pygame.Rect(rr.x+ (rr.width-4 if r["dx"]>0 else 0), rr.y+2, 4, rr.height-4))

    # Laser warnings & beams
    for lw in laser_warns:
        if lw["warn"] > 0:
            # crveni telegraph linija
            alpha = 80 + int(120 * (1 - lw["warn"]/35))
            s = pygame.Surface((lw["x_from"], 4), pygame.SRCALPHA)
            s.fill((255, 80, 80, alpha))
            screen.blit(s, (sx, lw["y"]-2+sy))
        else:
            # ispaljeni laser
            pygame.draw.rect(screen, (255, 200, 220), (sx, lw["y"]-3+sy, lw["x_from"], 6))
            pygame.draw.rect(screen, (200, 120, 255), (sx, lw["y"]-1+sy, lw["x_from"], 2))

    for e in enemies:
        e.draw()
        draw_bar(e.rect.x+sx, e.rect.y+sy - 10, e.rect.width, 6, e.hp, e.maxhp, (255, 80, 80))
        if e.max_shield > 0:
            draw_bar(e.rect.x+sx, e.rect.y+sy - 18, e.rect.width, 5, e.shield, e.max_shield, (80, 180, 255))
        # Variant tag
        if not e.boss and e.variant != "regular":
            tag = {"zerg":"Z","tank":"T","kamikaza":"K","sniper":"X"}[e.variant]
            col = TINTS[e.variant]
            draw_text(tag, e.rect.x+sx-4, e.rect.y+sy-32, col, small_font)

    # Crveni "swarm intensity" vignette
    intensity = min(1.0, len(enemies) / 14.0)
    if intensity > 0.4:
        v = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        a = int(60 * (intensity - 0.4) / 0.6)
        pygame.draw.rect(v, (180, 30, 30, a), (0, 0, WIDTH, HEIGHT), 60)
        screen.blit(v, (0, 0))

    # HUD
    draw_text(f"Wave: {wave}", 14, 12)
    draw_text(f"Score: {score}", 14, 50)
    draw_bar(14, 92, 280, 20, player_hp, player_max_hp, (80, 220, 80))
    draw_text(f"HP {int(player_hp)}/{player_max_hp}", 304, 90)
    sc_color = (120,120,120) if shield_locked else (80, 180, 255)
    draw_bar(14, 120, 280, 16, shield_energy, shield_max, sc_color)
    label = "SHIELD RECHARGING…" if shield_locked else "Shield (Q)"
    draw_text(f"{label}  {int(shield_energy)}", 304, 118,
              (200,200,200) if shield_locked else (255,255,255), small_font)

    draw_bar(14, 142, 280, 10, DASH_CD_MAX - dash_cd, DASH_CD_MAX, (200,200,80))
    draw_text("Dash (Shift)", 304, 140, f=small_font)

    rkt_col = (255,140,40) if rocket_cd <= 0 else (140,90,40)
    draw_bar(14, 156, 280, 10, ROCKET_CD_MAX - rocket_cd, ROCKET_CD_MAX, rkt_col)
    rkt_label = "ZOLJA (F) — READY" if rocket_cd <= 0 else f"ZOLJA (F)  {rocket_cd//60+1}s"
    draw_text(rkt_label, 304, 154, (255,180,80) if rocket_cd<=0 else (180,140,100), small_font)

    yy = 178
    if rapid_timer > 0:
        draw_text(f"⚡ RAPID  {rapid_timer//60+1}s", 14, yy, POW_COLORS["rapid"], small_font); yy += 22
    if triple_timer > 0:
        draw_text(f"※ TRIPLE  {triple_timer//60+1}s", 14, yy, POW_COLORS["triple"], small_font); yy += 22
    if mult_timer > 0:
        draw_text(f"x2 SCORE  {mult_timer//60+1}s", 14, yy, POW_COLORS["mult"], small_font); yy += 22

    # Stats compact (top-right)
    elapsed = int(time.time() - stats["start_ts"])
    draw_text(f"Kills: {stats['kills']}", WIDTH-180, 12, (220,220,220), small_font)
    draw_text(f"Time: {elapsed//60:02d}:{elapsed%60:02d}", WIDTH-180, 34, (220,220,220), small_font)
    acc = (stats["shots_hit"]/stats["shots_fired"]*100) if stats["shots_fired"] else 0
    draw_text(f"Acc: {acc:.0f}%", WIDTH-180, 56, (220,220,220), small_font)
    draw_text(f"Best: {hs_data.get('high_score',0)}", WIDTH-180, 78, (255,210,120), small_font)

    if combo > 1:
        draw_text(f"COMBO x{combo}", WIDTH-220, 110, (255,200,80))

    pygame.draw.line(screen, (255,255,255), (HALF_X+sx, 0), (HALF_X+sx, HEIGHT), 1)

    bosses = [e for e in enemies if e.boss]
    if bosses:
        b = bosses[0]
        draw_text("BOSS", WIDTH//2 - 50, 16, (255,80,80))
        draw_bar(WIDTH//2 - 200, 50, 400, 18, b.hp, b.maxhp, (255, 80, 80))
        if b.max_shield > 0:
            draw_bar(WIDTH//2 - 200, 30, 400, 12, b.shield, b.max_shield, (80, 180, 255))

    draw_text("A/D · W jump · SPACE · F zolja · Q shield · SHIFT dash · ESC pause",
              WIDTH-720, HEIGHT-26, (200,200,200), small_font)

    # Toasts (achievements / wave banner)
    ty = 220
    for t in toasts[:]:
        t["life"] -= 1
        if t["life"] <= 0:
            toasts.remove(t); continue
        alpha = min(255, t["life"]*4)
        surf = mid_font.render(t["text"], True, t["color"])
        surf.set_alpha(alpha)
        screen.blit(surf, surf.get_rect(center=(WIDTH//2, ty)))
        ty += 50

    # Pause overlay
    if paused and not game_over:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        screen.blit(overlay, (0, 0))
        draw_text_centered("PAUSED", WIDTH//2, HEIGHT//2 - 80, (255,255,255), big_font)
        draw_text_centered("ESC — Resume   ·   R — Restart   ·   Q — Quit",
                           WIDTH//2, HEIGHT//2 + 20, (220,220,220))

    if game_over:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 190))
        screen.blit(overlay, (0, 0))
        draw_text_centered("GAME OVER", WIDTH//2, HEIGHT//2 - 160, (255, 80, 80), big_font)
        elapsed = int(time.time() - stats["start_ts"])
        acc = (stats["shots_hit"]/stats["shots_fired"]*100) if stats["shots_fired"] else 0
        lines = [
            f"Score: {score}    Best: {hs_data.get('high_score',0)}",
            f"Wave reached: {wave}    Best wave: {hs_data.get('best_wave',0)}",
            f"Kills: {stats['kills']}    Max combo: {max_combo_run}",
            f"Accuracy: {acc:.1f}%    Time: {elapsed//60:02d}:{elapsed%60:02d}",
            "",
            "pritisni R za restart"
        ]
        yy = HEIGHT//2 - 40
        for ln in lines:
            draw_text_centered(ln, WIDTH//2, yy, (240,240,240))
            yy += 38

    pygame.display.flip()

pygame.quit()
