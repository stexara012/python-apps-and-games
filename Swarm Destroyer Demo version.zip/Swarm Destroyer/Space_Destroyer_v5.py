import pygame
import random
import os
import math

pygame.init()

# === WINDOW ===
WIDTH, HEIGHT = 1440, 810
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bridge Battle")
clock = pygame.time.Clock()

# === BG ===
background = pygame.image.load("background.png").convert()
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

SCALE = 1.5
SPRITE = int(64 * SCALE)
GROUND_Y = HEIGHT - int(220 * (HEIGHT / 600))
HALF_X = WIDTH // 2

# === FRAMES ===
def load_frames_from_folder(path):
    files = sorted(os.listdir(path), key=lambda x: int(x.split("_")[-1].split(".")[0]))
    out = []
    for f in files:
        if f.endswith(".png"):
            img = pygame.image.load(os.path.join(path, f)).convert_alpha()
            out.append(pygame.transform.scale(img, (SPRITE, SPRITE)))
    return out

player_frames = load_frames_from_folder("output/player_frames")
player_idle  = player_frames[0:5]
player_walk  = player_frames[5:10]
player_shoot = player_frames[10:15]

enemy_frames = load_frames_from_folder("output/enemy_frames")
soldier_fixed = [pygame.transform.flip(f, True, False) for f in enemy_frames[8:12]]
enemy_types = {
    "hover":   enemy_frames[0:4],
    "walker":  enemy_frames[4:8],
    "soldier": soldier_fixed,
    "flyer":   enemy_frames[12:15],
}
# Big boss frejmovi - svi tipovi neprijatelja uvećani 2.5x
BOSS_SCALE = 2.5
BOSS_SIZE = int(SPRITE * BOSS_SCALE)
boss_frame_sets = {
    name: [pygame.transform.scale(f, (BOSS_SIZE, BOSS_SIZE)) for f in frames]
    for name, frames in enemy_types.items()
}

# === PROCEDURAL SOUND (bez fajlova) ===
try:
    pygame.mixer.init(frequency=22050, size=-16, channels=1)
    import array
    def make_beep(freq, ms, vol=0.25, decay=True):
        sr = 22050
        n = int(sr * ms / 1000)
        buf = array.array("h")
        amp = int(32767 * vol)
        for i in range(n):
            t = i / sr
            env = (1 - i/n) if decay else 1
            v = int(math.sin(2*math.pi*freq*t) * amp * env)
            buf.append(v)
        return pygame.mixer.Sound(buffer=buf.tobytes())
    snd_shoot = make_beep(880, 60, 0.18)
    snd_hit   = make_beep(220, 80, 0.28)
    snd_pick  = make_beep(1200, 120, 0.25)
    snd_dmg   = make_beep(120, 150, 0.35)
    snd_jump  = make_beep(520, 80, 0.18)
    SOUND = True
except Exception:
    SOUND = False

def play(s):
    if SOUND:
        try: s.play()
        except: pass

# === PLAYER ===
player = pygame.Rect(150, GROUND_Y, SPRITE, SPRITE)
player_speed = 6
player_anim = player_idle
frame_index = 0
anim_speed = 0.15
state = "idle"
facing_right = True

player_max_hp = 100
player_hp = 100

shield_max = 100
shield_energy = 100
shield_active = False
shield_locked = False
shield_regen = 0.18
shield_drain = 0.55
SHIELD_PAD = 70

vel_y = 0
on_ground = True
GRAVITY = 0.9
JUMP_V = -16

shoot_cooldown = 0
SHOOT_DELAY = 18

# Dash (Shift)
dash_cd = 0
DASH_CD_MAX = 90
dash_time = 0
DASH_DUR = 10
dash_dir = 1

# Power-up timeri
rapid_timer = 0       # frejmova preostalo
triple_timer = 0
mult_timer = 0        # score x2

# Combo
combo = 0
combo_timer = 0
COMBO_WINDOW = 90

# Screen shake
shake = 0

bullets = []
enemy_bullets = []
particles = []   # {x,y,vx,vy,life,col,size}
powerups = []    # {rect,type}

POW_TYPES = ["heal", "rapid", "triple", "shield", "mult"]
POW_COLORS = {"heal":(80,255,120), "rapid":(255,220,80),
              "triple":(255,140,80), "shield":(80,180,255), "mult":(220,120,255)}

# Pickup-i koje neprijatelji ispuštaju
# hp_pack vraća HP, shield_pack puni shield
PICKUP_COLORS = {"hp_pack": (80,255,120), "shield_pack": (80,180,255)}

def spawn_particles(x, y, color, n=14, speed=4, life=28):
    for _ in range(n):
        a = random.random()*math.tau
        sp = random.uniform(speed*0.3, speed)
        particles.append({"x":x,"y":y,"vx":math.cos(a)*sp,"vy":math.sin(a)*sp,
                          "life":life,"max":life,"col":color,"size":random.randint(2,4)})

class Enemy:
    def __init__(self, boss=False, wave_num=1):
        self.boss = boss
        if boss:
            # Big boss = nasumičan tip neprijatelja, ali uvećan
            self.type = random.choice(list(boss_frame_sets.keys()))
            self.anim = boss_frame_sets[self.type]
            y = GROUND_Y - (BOSS_SIZE - SPRITE) if self.type != "flyer" else GROUND_Y - 160
            self.rect = pygame.Rect(WIDTH, y, BOSS_SIZE, BOSS_SIZE)
            # Boss HP raste sa wave-om
            self.maxhp = 30 + wave_num * 5
            self.hp = self.maxhp
            self.speed = 1
            # Boss shield
            self.max_shield = 40 + wave_num * 3
            self.shield = self.max_shield
        else:
            self.type = random.choice(list(enemy_types.keys()))
            self.anim = enemy_types[self.type]
            y = GROUND_Y if self.type != "flyer" else GROUND_Y - 120
            self.rect = pygame.Rect(WIDTH, y, SPRITE, SPRITE)
            speeds = {"hover":3, "walker":2, "soldier":2, "flyer":4}
            self.speed = speeds[self.type]
            # HP raste svaki wave
            self.maxhp = 3 + wave_num // 2
            self.hp = self.maxhp
            # Od wave 3+ neki neprijatelji imaju shield
            if wave_num >= 3 and random.random() < min(0.15 + wave_num*0.04, 0.6):
                self.max_shield = 2 + wave_num // 2
                self.shield = self.max_shield
            else:
                self.max_shield = 0
                self.shield = 0
        self.frame = 0
        self.shoot_timer = random.randint(60, 180)

    def update(self):
        target_x = HALF_X - (self.rect.width if self.boss else 0)
        if self.rect.x > target_x:
            self.rect.x -= self.speed
        self.frame = (self.frame + 0.1) % len(self.anim)
        self.shoot_timer -= 1
        if self.shoot_timer <= 0 and self.rect.x <= HALF_X + 250:
            if self.boss:
                # 5 metaka u širokoj lepezi
                for ang in (-0.3, -0.15, 0, 0.15, 0.3):
                    eb = pygame.Rect(self.rect.centerx, self.rect.centery, 14, 6)
                    enemy_bullets.append({"rect": eb, "dx": -8, "dy": ang*8})
                self.shoot_timer = random.randint(50, 90)
            else:
                eb = pygame.Rect(self.rect.centerx, self.rect.centery, 12, 5)
                enemy_bullets.append({"rect": eb, "dx": -8, "dy": 0})
                self.shoot_timer = random.randint(90, 200)

    def draw(self):
        img = self.anim[int(self.frame)]
        screen.blit(img, img.get_rect(center=self.rect.center))

enemies = []
wave = 1
spawn_timer = 0
enemies_to_spawn = 5
boss_spawned = False
score = 0
game_over = False

font = pygame.font.SysFont(None, 36)
big_font = pygame.font.SysFont(None, 96)
small_font = pygame.font.SysFont(None, 24)

def draw_text(t, x, y, c=(255,255,255), f=font):
    screen.blit(f.render(t, True, c), (x, y))

def draw_bar(x, y, w, h, value, maxv, color, bg=(40,40,40)):
    pygame.draw.rect(screen, bg, (x, y, w, h))
    fw = int(w * max(0, value) / maxv)
    pygame.draw.rect(screen, color, (x, y, fw, h))
    pygame.draw.rect(screen, (200,200,200), (x, y, w, h), 2)

def reset_game():
    global player_hp, shield_energy, shield_locked, wave, enemies_to_spawn, score
    global game_over, vel_y, on_ground, boss_spawned, combo, combo_timer
    global rapid_timer, triple_timer, mult_timer, dash_cd
    global player_max_hp, shield_max
    player.x, player.y = 150, GROUND_Y
    player_max_hp = 100
    shield_max = 100
    player_hp = player_max_hp
    shield_energy = shield_max
    shield_locked = False
    bullets.clear(); enemy_bullets.clear(); enemies.clear()
    particles.clear(); powerups.clear()
    wave = 1; enemies_to_spawn = 5; score = 0
    game_over = False; vel_y = 0; on_ground = True
    boss_spawned = False
    combo = 0; combo_timer = 0
    rapid_timer = triple_timer = mult_timer = 0
    dash_cd = 0

running = True
while running:
    clock.tick(60)

    # Screen shake offset
    sx = random.randint(-shake, shake) if shake else 0
    sy = random.randint(-shake, shake) if shake else 0
    if shake > 0: shake -= 1

    screen.blit(background, (sx, sy))

    keys = pygame.key.get_pressed()
    moving = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if game_over and event.key == pygame.K_r:
                reset_game()
            if not game_over:
                if event.key == pygame.K_SPACE and shoot_cooldown <= 0:
                    delay = SHOOT_DELAY // 2 if rapid_timer > 0 else SHOOT_DELAY
                    dx = 14 if facing_right else -14
                    bx = player.centerx + (24 if facing_right else -24)
                    if triple_timer > 0:
                        for off in (-10, 0, 10):
                            bullets.append({"rect": pygame.Rect(bx, player.centery+off, 12, 5), "dx": dx, "dy": off*0.05})
                    else:
                        bullets.append({"rect": pygame.Rect(bx, player.centery, 12, 5), "dx": dx, "dy": 0})
                    spawn_particles(bx, player.centery, (255,230,120), n=6, speed=3, life=10)
                    state = "shoot"; shoot_cooldown = delay
                    play(snd_shoot)
                if event.key == pygame.K_w and on_ground:
                    vel_y = JUMP_V; on_ground = False
                    play(snd_jump)
                    spawn_particles(player.centerx, player.bottom, (200,200,200), n=8, speed=2, life=14)
                if event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT) and dash_cd <= 0:
                    dash_time = DASH_DUR
                    dash_dir = 1 if facing_right else -1
                    dash_cd = DASH_CD_MAX

    if not game_over:
        # === MOVE ===
        if keys[pygame.K_a]:
            player.x -= player_speed; moving = True; facing_right = False
        if keys[pygame.K_d]:
            player.x += player_speed; moving = True; facing_right = True

        # Dash
        if dash_time > 0:
            player.x += dash_dir * 18
            spawn_particles(player.centerx, player.centery, (180,220,255), n=2, speed=1, life=12)
            dash_time -= 1
        if dash_cd > 0: dash_cd -= 1

        player.x = max(0, min(WIDTH - player.width, player.x))

        vel_y += GRAVITY
        player.y += int(vel_y)
        if player.y >= GROUND_Y:
            player.y = GROUND_Y; vel_y = 0; on_ground = True

        # Shield
        wants = keys[pygame.K_q]
        if shield_locked:
            shield_active = False
            shield_energy = min(shield_max, shield_energy + shield_regen)
            if shield_energy >= shield_max:
                shield_locked = False
        else:
            shield_active = wants and shield_energy > 0
            if shield_active:
                shield_energy -= shield_drain
                if shield_energy <= 0:
                    shield_energy = 0; shield_active = False; shield_locked = True
            else:
                shield_energy = min(shield_max, shield_energy + shield_regen)

        if shoot_cooldown > 0: shoot_cooldown -= 1
        if rapid_timer > 0: rapid_timer -= 1
        if triple_timer > 0: triple_timer -= 1
        if mult_timer > 0: mult_timer -= 1
        if combo_timer > 0:
            combo_timer -= 1
            if combo_timer == 0: combo = 0

        # Anim
        if state == "shoot":   player_anim = player_shoot
        elif moving:           player_anim = player_walk
        else:                  player_anim = player_idle
        frame_index = (frame_index + anim_speed) % len(player_anim)
        if state == "shoot" and frame_index < anim_speed: state = "idle"

        # Bullets
        for b in bullets:
            b["rect"].x += b["dx"]
            b["rect"].y += int(b.get("dy", 0))
        bullets = [b for b in bullets if 0 < b["rect"].x < WIDTH]
        for b in enemy_bullets:
            b["rect"].x += b["dx"]
            b["rect"].y += int(b.get("dy", 0))
        enemy_bullets = [b for b in enemy_bullets if 0 < b["rect"].x < WIDTH]

        # Spawn — swarm: brže spawnovanje + povremeni burst
        spawn_timer += 1
        spawn_delay = max(18, 60 - wave * 3)  # sa wave-om brže
        if spawn_timer > spawn_delay and enemies_to_spawn > 0:
            enemies.append(Enemy(wave_num=wave))
            spawn_timer = 0
            enemies_to_spawn -= 1
            # Swarm burst — od wave 2+ ponekad spawn 2-3 odjednom
            if wave >= 2 and enemies_to_spawn > 0 and random.random() < 0.25:
                burst = min(random.randint(1, 2 + wave // 3), enemies_to_spawn)
                for _ in range(burst):
                    e = Enemy(wave_num=wave)
                    e.rect.x += random.randint(40, 200)
                    enemies.append(e)
                    enemies_to_spawn -= 1

        # Big boss svaki 3. wave
        if wave % 3 == 0 and not boss_spawned and enemies_to_spawn == 0 and len([e for e in enemies if not e.boss]) == 0:
            enemies.append(Enemy(boss=True, wave_num=wave))
            boss_spawned = True

        for e in enemies: e.update()

        # Bullets vs enemies — shield neprijatelja prvo apsorbuje
        for b in bullets[:]:
            for e in enemies[:]:
                if b["rect"].colliderect(e.rect):
                    if e.shield > 0:
                        e.shield -= 1
                        spawn_particles(b["rect"].x, b["rect"].y, (140,220,255), n=8, speed=3, life=12)
                    else:
                        e.hp -= 1
                        spawn_particles(b["rect"].x, b["rect"].y, (255,200,80), n=8, speed=3, life=14)
                    if b in bullets: bullets.remove(b)
                    play(snd_hit)
                    if e.hp <= 0:
                        spawn_particles(e.rect.centerx, e.rect.centery, (255,120,80), n=24, speed=6, life=30)
                        if e.boss:
                            shake = 14
                            score += 200 * (2 if mult_timer>0 else 1)
                            # Boss uvek dropuje hp + shield pack
                            for i, pt in enumerate(("hp_pack", "shield_pack")):
                                powerups.append({"rect": pygame.Rect(e.rect.centerx-12 + i*40, GROUND_Y+20, 24, 24), "type": pt})
                            # + power-up
                            t = random.choice(POW_TYPES)
                            powerups.append({"rect": pygame.Rect(e.rect.centerx-12 - 40, GROUND_Y+20, 24, 24), "type": t})
                        else:
                            combo += 1; combo_timer = COMBO_WINDOW
                            base = 10 + combo*2
                            score += base * (2 if mult_timer>0 else 1)
                            # Drop logika: hp/shield pack češće, power-up ređe
                            r = random.random()
                            if r < 0.18:
                                powerups.append({"rect": pygame.Rect(e.rect.centerx-12, GROUND_Y+20, 24, 24), "type": "hp_pack"})
                            elif r < 0.32:
                                powerups.append({"rect": pygame.Rect(e.rect.centerx-12, GROUND_Y+20, 24, 24), "type": "shield_pack"})
                            elif r < 0.50:
                                t = random.choice(POW_TYPES)
                                powerups.append({"rect": pygame.Rect(e.rect.centerx-12, GROUND_Y+20, 24, 24), "type": t})
                        enemies.remove(e)
                    break

        # Enemy bullets vs player
        shield_rect = player.inflate(SHIELD_PAD, SHIELD_PAD)
        for b in enemy_bullets[:]:
            if shield_active and b["rect"].colliderect(shield_rect):
                enemy_bullets.remove(b)
                spawn_particles(b["rect"].x, b["rect"].y, (140,220,255), n=8, speed=3, life=14)
                continue
            if b["rect"].colliderect(player):
                enemy_bullets.remove(b); player_hp -= 8
                spawn_particles(player.centerx, player.centery, (255,80,80), n=10, speed=4, life=18)
                shake = max(shake, 6); play(snd_dmg)

        for e in enemies[:]:
            if e.rect.colliderect(player):
                if not shield_active:
                    player_hp -= 0.5
                else:
                    e.rect.x -= 4

        # Powerups pickup
        for p in powerups[:]:
            if p["rect"].colliderect(player):
                t = p["type"]
                if t == "heal":     player_hp = min(player_max_hp, player_hp + 30)
                elif t == "rapid":  rapid_timer = 60*6
                elif t == "triple": triple_timer = 60*6
                elif t == "shield":
                    shield_energy = shield_max; shield_locked = False
                elif t == "mult":   mult_timer = 60*8
                elif t == "hp_pack":
                    player_hp = min(player_max_hp, player_hp + 25)
                elif t == "shield_pack":
                    shield_energy = min(shield_max, shield_energy + 35)
                    if shield_energy >= shield_max * 0.5: shield_locked = False
                col = POW_COLORS.get(t, PICKUP_COLORS.get(t, (255,255,255)))
                spawn_particles(p["rect"].centerx, p["rect"].centery, col, n=16, speed=4, life=22)
                play(snd_pick)
                powerups.remove(p)

        if player_hp <= 0:
            player_hp = 0; game_over = True; shake = 16

        if len(enemies) == 0 and enemies_to_spawn == 0 and (wave % 3 != 0 or boss_spawned):
            wave += 1
            enemies_to_spawn = 5 + wave * 2
            boss_spawned = False
            # Posle svakog wave-a: veći max HP i shield kapacitet
            player_max_hp += 10
            shield_max += 8
            # Mali bonus heal/recharge na kraju wave-a
            player_hp = min(player_max_hp, player_hp + 15)
            shield_energy = min(shield_max, shield_energy + 20)


    # Particles update + draw
    for p in particles[:]:
        p["x"] += p["vx"]; p["y"] += p["vy"]
        p["vy"] += 0.15
        p["life"] -= 1
        if p["life"] <= 0: particles.remove(p); continue
        a = max(0, min(255, int(255 * p["life"]/p["max"])))
        s = pygame.Surface((p["size"]*2, p["size"]*2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*p["col"], a), (p["size"], p["size"]), p["size"])
        screen.blit(s, (p["x"]+sx-p["size"], p["y"]+sy-p["size"]))

    # Powerups draw (pulsiranje)
    t_now = pygame.time.get_ticks() / 200
    for p in powerups:
        c = POW_COLORS.get(p["type"], PICKUP_COLORS.get(p["type"], (255,255,255)))
        r = p["rect"].copy(); r.x += sx; r.y += sy
        pulse = 4 + int(3*math.sin(t_now))
        s = pygame.Surface((r.width+pulse*2, r.height+pulse*2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*c, 80), (s.get_width()//2, s.get_height()//2), s.get_width()//2)
        screen.blit(s, (r.x-pulse, r.y-pulse))
        pygame.draw.rect(screen, c, r)
        letters = {"heal":"+", "rapid":"R", "triple":"3", "shield":"S", "mult":"x2",
                   "hp_pack":"♥", "shield_pack":"◊"}
        letter = letters.get(p["type"], "?")
        draw_text(letter, r.x+4, r.y+2, (10,10,10), small_font)

    # Player
    img = player_anim[int(frame_index)]
    if not facing_right: img = pygame.transform.flip(img, True, False)
    screen.blit(img, img.get_rect(center=(player.centerx+sx, player.centery+sy)))

    # Shield aura
    if shield_active and not shield_locked:
        sr = player.inflate(SHIELD_PAD, SHIELD_PAD)
        s = pygame.Surface((sr.width, sr.height), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (60, 180, 255, 70), s.get_rect())
        pygame.draw.ellipse(s, (140, 230, 255, 220), s.get_rect(), 4)
        screen.blit(s, (sr.x+sx, sr.y+sy))

    for b in bullets:
        pygame.draw.rect(screen, (255, 255, 120), b["rect"].move(sx,sy))
    for b in enemy_bullets:
        pygame.draw.rect(screen, (255, 80, 80), b["rect"].move(sx,sy))

    for e in enemies:
        e.draw()
        # HP bar
        draw_bar(e.rect.x+sx, e.rect.y+sy - 10, e.rect.width, 6, e.hp, e.maxhp, (255, 80, 80))
        # Shield bar (iznad HP-a) ako ima shield
        if e.max_shield > 0:
            draw_bar(e.rect.x+sx, e.rect.y+sy - 18, e.rect.width, 5, e.shield, e.max_shield, (80, 180, 255))

    # HUD
    draw_text(f"Wave: {wave}", 14, 12)
    draw_text(f"Score: {score}", 14, 50)
    draw_bar(14, 92, 280, 20, player_hp, player_max_hp, (80, 220, 80))
    draw_text(f"HP {int(player_hp)}/{player_max_hp}", 304, 90)
    sc_color = (120,120,120) if shield_locked else (80, 180, 255)
    draw_bar(14, 120, 280, 16, shield_energy, shield_max, sc_color)
    label = "SHIELD RECHARGING…" if shield_locked else "Shield (Q)"
    draw_text(f"{label}  {int(shield_energy)}", 304, 118,
              (200,200,200) if shield_locked else (255,255,255), small_font)

    # Dash cd
    draw_bar(14, 142, 280, 10, DASH_CD_MAX - dash_cd, DASH_CD_MAX, (200,200,80))
    draw_text("Dash (Shift)", 304, 140, f=small_font)

    # Power-up indikatori
    yy = 168
    if rapid_timer > 0:
        draw_text(f"⚡ RAPID  {rapid_timer//60+1}s", 14, yy, POW_COLORS["rapid"], small_font); yy += 22
    if triple_timer > 0:
        draw_text(f"※ TRIPLE  {triple_timer//60+1}s", 14, yy, POW_COLORS["triple"], small_font); yy += 22
    if mult_timer > 0:
        draw_text(f"x2 SCORE  {mult_timer//60+1}s", 14, yy, POW_COLORS["mult"], small_font); yy += 22

    # Combo
    if combo > 1:
        draw_text(f"COMBO x{combo}", WIDTH-220, 20, (255,200,80))

    pygame.draw.line(screen, (255,255,255), (HALF_X+sx, 0), (HALF_X+sx, HEIGHT), 1)

    # Boss indikator
    bosses = [e for e in enemies if e.boss]
    if bosses:
        b = bosses[0]
        draw_text("BOSS", WIDTH//2 - 50, 16, (255,80,80))
        draw_bar(WIDTH//2 - 200, 50, 400, 18, b.hp, b.maxhp, (255, 80, 80))

    # Controls hint
    draw_text("A/D move · W jump · SPACE shoot · Q shield · SHIFT dash",
              WIDTH-560, HEIGHT-26, (200,200,200), small_font)

    if game_over:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        screen.blit(overlay, (0, 0))
        draw_text("GAME OVER", WIDTH//2 - 240, HEIGHT//2 - 80, (255, 80, 80), big_font)
        draw_text(f"Score: {score}   —   pritisni R za restart",
                  WIDTH//2 - 240, HEIGHT//2 + 30)

    pygame.display.flip()

pygame.quit()
