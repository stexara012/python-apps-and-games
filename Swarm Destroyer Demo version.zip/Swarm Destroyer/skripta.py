import pygame
import os

pygame.init()
pygame.display.set_mode((1,1))  # obavezno za convert_alpha

# === SETTINGS ===
INPUT_FOLDER = "input"
OUTPUT_FOLDER = "output"

TILE_SIZE = 64

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# === DETECT FUNCTION ===
def detect_sprites(img):
    width, height = img.get_size()
    visited = set()
    sprites = []

    def is_pixel_used(x, y):
        return img.get_at((x, y)).a > 10

    for y in range(height):
        for x in range(width):
            if (x, y) in visited:
                continue
            if not is_pixel_used(x, y):
                continue

            stack = [(x, y)]
            min_x, min_y = x, y
            max_x, max_y = x, y

            while stack:
                px, py = stack.pop()

                if (px, py) in visited:
                    continue
                if px < 0 or py < 0 or px >= width or py >= height:
                    continue
                if not is_pixel_used(px, py):
                    continue

                visited.add((px, py))

                min_x = min(min_x, px)
                min_y = min(min_y, py)
                max_x = max(max_x, px)
                max_y = max(max_y, py)

                stack.extend([
                    (px+1, py), (px-1, py),
                    (px, py+1), (px, py-1)
                ])

            sprites.append((min_x, min_y, max_x, max_y))

    sprites.sort(key=lambda b: (b[1], b[0]))
    return sprites

# === PROCESS FILE ===
def process_image(filename):
    print(f"🔄 Obrada: {filename}")

    path = os.path.join(INPUT_FOLDER, filename)
    img = pygame.image.load(path).convert_alpha()

    sprites = detect_sprites(img)
    print(f"   Nađeno sprite-ova: {len(sprites)}")

    # === OUTPUT PATHS ===
    name = os.path.splitext(filename)[0]
    sheet_out = os.path.join(OUTPUT_FOLDER, f"{name}_clean.png")
    frames_folder = os.path.join(OUTPUT_FOLDER, f"{name}_frames")

    os.makedirs(frames_folder, exist_ok=True)

    # === GRID SIZE ===
    cols = int(len(sprites) ** 0.5) + 1
    rows = (len(sprites) // cols) + 1

    clean = pygame.Surface((cols * TILE_SIZE, rows * TILE_SIZE), pygame.SRCALPHA)

    # === COPY ===
    i = 0
    for row in range(rows):
        for col in range(cols):
            if i >= len(sprites):
                break

            min_x, min_y, max_x, max_y = sprites[i]
            sprite = img.subsurface((min_x, min_y, max_x - min_x + 1, max_y - min_y + 1))

            # save individual frame
            frame_path = os.path.join(frames_folder, f"{name}_{i}.png")
            pygame.image.save(sprite, frame_path)

            # center into grid
            x_offset = (TILE_SIZE - sprite.get_width()) // 2
            y_offset = (TILE_SIZE - sprite.get_height()) // 2

            clean.blit(sprite, (col * TILE_SIZE + x_offset, row * TILE_SIZE + y_offset))

            i += 1

    pygame.image.save(clean, sheet_out)
    print(f"   ✅ Sačuvano: {sheet_out}")

# === MAIN ===
for file in os.listdir(INPUT_FOLDER):
    if file.endswith(".png"):
        process_image(file)

print("\n🎉 Gotovo! Svi sprite-ovi obrađeni.")